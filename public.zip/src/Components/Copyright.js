import React from "react";

const Copyright = () => {
  return (
    <>
      <div className="copyright">
        <div className="container">
          <div className="row">
            <div className="col-12">
              <p>
                Copyright ©2021 All rights reserved | This template is made with
                by Ashish Ratewal
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Copyright;
